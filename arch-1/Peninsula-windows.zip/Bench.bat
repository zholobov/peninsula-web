@echo off
rem Peninsula frame-time bench (docs/TODO.md, the stream order, step 1).
rem Fullscreen, by itself; Esc stops it. It writes bench-<date>-<time>.txt
rem next to Peninsula.exe, then this opens the folder.
start "" /wait "%~dp0Peninsula.exe" --fullscreen -- --bench
explorer "%~dp0."
