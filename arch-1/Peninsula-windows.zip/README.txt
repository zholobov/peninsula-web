Peninsula for Windows

Peninsula.exe  The game.

Bench.bat      The frame-time benchmark. It runs by itself, fullscreen, for
               10 to 20 minutes; Esc stops it early. When it ends, this
               folder opens with a new bench-<date>-<time>.txt in it: please
               send that file. Run it twice and send both: the first run
               includes Windows compiling the game's shaders for the first
               time.

The exe is not signed, so Windows may say "Windows protected your PC":
click "More info", then "Run anyway".
